import 'package:flutter/material.dart';

class PostTile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text("Post Tile");
  }
}
